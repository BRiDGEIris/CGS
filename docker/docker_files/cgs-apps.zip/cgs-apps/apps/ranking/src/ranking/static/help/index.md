Help for your app, written in [MarkDown](http://daringfireball.net/projects/markdown/syntax) syntax.
